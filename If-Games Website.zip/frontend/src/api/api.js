import axios from 'axios';
const API_URL = 'https://apis.vnvision.in/';
export const IMAGE_URL = 'https://apis.vnvision.in/';



export const CONTACT_API_URL = 'https://apis.vnvision.in/newContact';



export const fetchTeam = () => axios.get(`${API_URL}api/teams`);
export const fetchservices = ()=> axios.get(`${API_URL}api/services`)
export const fetchTestimonials = ()=> axios.get(`${API_URL}api/testimonials`)
export const fetchproducts = ()=> axios.get(`${API_URL}api/products`)
export const fetchslides = ()=> axios.get(`${API_URL}api/sliders`)
export const fetchprivacy = ()=> axios.get(`${API_URL}api/privacy`)
export const fetchclient = ()=> axios.get(`${API_URL}api/companyModel`)
export const fetchFooterImages = () => axios.get(`${API_URL}api/home-footer-image`);
export const fetchSocialLinks = () => axios.get(`${API_URL}api/footers`);
export const fetchmissionvision = () => axios.get(`${API_URL}api/missionvision`)
export const fetchheroimg = () => axios.get(`${API_URL}api/teamheader`)
export const fetchcontactdetails = () => axios.get(`${API_URL}api/contactdetail`)

