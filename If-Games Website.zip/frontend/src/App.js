import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import './index.css';
import ScrollToTop from "./components/ScrollToTop";
import Home from './components/home/Home';
import Services from './components/services/Services';
import Products from './components/products/Products';
import Team from './components/team/Team';
import Contact from './components/contact/Contact';
import Footer from './components/Footer';
import Teams from './components/team/Team';
import PrivacyPolicy from './components/Privacy-Policy/Privacy';
import TermsAndConditions from './components/Terms-Conditions/Terms';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import Navbar from './components/Navbar';
import Preloader from './components/preloader/Preloader'; // Import Preloader
import CustomCursor from './CustomCursor'; // Import CustomCursor

function App() {
  const [language, setLanguage] = useState("en"); // Default language
  const [loading, setLoading] = useState(true); // Add loading state

  // Load saved language from localStorage when the app mounts
  useEffect(() => {
    const savedLanguage = localStorage.getItem("selectedLanguage");
    if (savedLanguage) {
      setLanguage(savedLanguage); // Set the saved language
    }
  }, []);

  // Simulate loading or API call
  useEffect(() => {
    setTimeout(() => {
      setLoading(false); // Set loading to false after 2 seconds
    }, 2000);
  }, []);

  // Handle language change and save it to localStorage
  const handleLanguageChange = (lang) => {
    setLanguage(lang); // Update the state
    localStorage.setItem("selectedLanguage", lang); // Save language to localStorage
  };

  // Conditionally render Preloader or Main App content
  if (loading) {
    return <Preloader />;
  }

  return (
    <BrowserRouter>
      <Navbar handleLanguageChange={handleLanguageChange} language={language} />
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home language={language} />} />
        <Route path="/Home" element={<Home language={language} />} />
        <Route path="/services" element={<Services language={language} />} />
        <Route path="/products" element={<Products language={language} />} />
        <Route path="/team" element={<Teams language={language} />} />
        <Route path="/contact" element={<Contact language={language} />} />
        <Route path="/terms-and-conditions" element={<TermsAndConditions language={language} />} />
        <Route path="/privacy-policy" element={<PrivacyPolicy language={language} />} />
      </Routes>
      <Footer language={language} />
      <CustomCursor /> {/* Add CustomCursor here */}
    </BrowserRouter>
  );
}

export default App;