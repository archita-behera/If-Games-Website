import React from 'react';
import './Preloader.css';

function Preloader() {
  return (
    <div className="preloader">
      <img
        src="/images/GameStudioLogo-removebg-preview 1.png" // Update with the correct path to your image
        alt="Loading..."
        className="preloader-image"
      />
    </div>
  );
}

export default Preloader;