import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { useTranslation } from "react-i18next";
import "./Navbar.css";

function Navbar({ handleLanguageChange }) {
  const { t, i18n } = useTranslation();

  const [isCollapsed, setIsCollapsed] = useState(false);
  const [language, setLanguage] = useState(localStorage.getItem("selectedLanguage") || "en");

  // Initialize language state and i18n on component mount
  useEffect(() => {
    i18n.changeLanguage(language);
    handleLanguageChange(language); // Notify parent of initial language
  }, [language, i18n, handleLanguageChange]);

  const toggleNavbar = () => {
    setIsCollapsed(!isCollapsed);
  };

  const closeNavbar = () => {
    setIsCollapsed(false);
  };

  const changeLanguage = (lng) => {
    setLanguage(lng); // Update local state
    localStorage.setItem("selectedLanguage", lng); // Save to localStorage
    i18n.changeLanguage(lng); // Update i18n language
    handleLanguageChange(lng); // Notify parent about the change
  };

  const menuItems =
    language === "ar"
      ? ["contact", "team", "products", "services", "home"]
      : ["home", "services", "products", "team", "contact"];

  return (
    <nav
      className="navbar navbar-expand-lg nav-bar"
      style={{
        position: "absolute",
        width: "100%",
        zIndex: 3,
        border: "none",
      }}
    >
      <div className="container">
        <NavLink className="navbar-brand" to="/">
          <img
            src="/images/GameStudioLogo-removebg-preview 1.png"
            style={{ width: "60%" }}
            alt="Logo"
          />
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded={isCollapsed ? "true" : "false"}
          aria-label="Toggle navigation"
          onClick={toggleNavbar}
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div
          className={`collapse navbar-collapse ${isCollapsed ? "show" : ""}`}
          id="navbarNav"
        >
          <ul className="navbar-nav justify-content-end flex-grow-1">
            {menuItems.map((item) => (
              <li className="nav-item" key={item}>
                <NavLink
                  className="nav-link"
                  to={`/${item}`}
                  style={({ isActive }) => ({
                    color: isActive ? "#00FFCC" : "white",
                  })}
                  onClick={closeNavbar} // Close navbar on click
                >
                  {t(item)}
                </NavLink>
              </li>
            ))}
          </ul>

          <button
            className="btn btn-outline-info navlogo rounded-pill d-flex align-items-center justify-content-center"
            style={{
              background: "linear-gradient(135deg, #6a0dad, #00f0ff)",
              border: "none",
              boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
              zIndex: 2,
            }}
            onClick={() => window.location.href = "#"}
          >
            <a href="https://inn.vnvision.in/" rel="noopener noreferrer">
              <img
                src="/images/white icon logo 1.png"
                alt="Secondary Logo"
                style={{ width: "70px", height: "30px" }}
              />
            </a>
          </button>

          <div className="dropdown ps-2">
            <select
              id="languageSelect"
              className="dropdown-select"
              value={language}
              onChange={(e) => changeLanguage(e.target.value)}
            >
              <option value="en" style={{ color: "black" }}>
                English
              </option>
              <option value="ar" style={{ color: "black" }}>
                Arabic
              </option>
            </select>
          </div>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;