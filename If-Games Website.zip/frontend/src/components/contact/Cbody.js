// import React from 'react';
// import './Contact.css';

// function Cbody() {
//     return (

//         <>
//            <div className="container my-4">
//     <div className="row mt-5">
//         <div className="col-md-8">
//             <form className="p-5 contact-form">
//                 <div className="form-header">
//                     <hr className="line-left" />
//                     <h2 className="form-title">CONTACT US</h2>
//                     <hr className="line-right" />
//                 </div>
//                 <h2 className="form-subtitle">Get In Touch With Us Today!</h2>

//                 <div className="form-row mb-4">
//                     <div className="form-group col-md-6">
//                         <label htmlFor="firstName" className="name">First Name</label>
//                         <input type="text" className="form-control box" id="firstName" placeholder="John" />
//                     </div>
//                     <div className="form-group col-md-6">
//                         <label htmlFor="lastName" className="name">Last Name</label>
//                         <input type="text" className="form-control box" id="lastName" placeholder="Doe" />
//                     </div>
//                 </div>

//                 <div className="form-row mb-4">
//                     <div className="form-group col-md-6">
//                         <label htmlFor="email" className="name">Email Address</label>
//                         <input type="email" className="form-control box" id="email" placeholder="yourname@example.com" />
//                     </div>
//                     <div className="form-group col-md-6">
//                         <label htmlFor="phone" className="name">Phone (Optional)</label>
//                         <input type="text" className="form-control box" id="phone" placeholder="Example: +849 51 843 9649" />
//                     </div>
//                 </div>

//                 <div className="form-row mb-4">
//                     <div className="form-group col-12">
//                         <label htmlFor="message" className="name">Message</label>
//                         <textarea className="form-control box2" id="message" placeholder="Leave your message here.." rows="5"></textarea>
//                     </div>
//                 </div>
//                 <div>
//                     <button type="button" className="btn btn-dark cbutton rounded-pill d-flex align-items-center mx-auto">
//                         <span>Submit Message</span>
//                         <i className="bi bi-arrow-right ml-2"></i>
//                     </button>
//                 </div>
//             </form>
//         </div>

//         <div className="col-lg-3 col-md-6 col-sm-12">
//             {/* Additional service cards... */}
//         </div>
//     </div>
// </div>

//             {/* Google Maps Embed */}

//             <div className="container d-flex justify-content-center my-5">
//                 <iframe className="map"
//                     src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3741.7795144577035!2d85.81686097484119!3d20.309391481165946!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a1909b9951ae649%3A0x975cd763534e6517!2z4KSr4KWJ4KSw4KWN4KSa4KWN4KSv4KWC4KSoIOCkn-ClieCkteCksA!5e0!3m2!1shi!2sin!4v1728294287315!5m2!1shi!2sin"
//                     referrerPolicy="no-referrer-when-downgrade"
//                     style={{ border: 0 }}
//                     allowFullScreen=""
//                     loading="lazy"
//                 ></iframe>
//             </div>





//         </>
//     );
// }

// export default Cbody;