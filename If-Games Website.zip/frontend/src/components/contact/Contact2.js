import React, { useState,useEffect } from 'react';
import axios from 'axios';
import './Contact2.css';
import {  fetchcontactdetails,IMAGE_URL,CONTACT_API_URL } from "../../api/api";
function Contact2({ language }) {
    const [formData, setFormData] = useState({
        firstName: { en: '', ar: '' },
        lastName: { en: '', ar: '' },
        email: '',
        phone: '',
        message: { en: '', ar: '' },
        countryCode: '+966' // Default country code
    });

    const [errors, setErrors] = useState({
        firstName: false,
        lastName: false,
        email: false,
        phone: false,
        message: false
    });

    const countryCodes = [
      { code: "+91" },
    { code: "+1"},
    { code: "+44" },
    { code: "+61" },
    { code: "+971" },
    { code: "+966" },
    { code: "+81" },
    { code: "+49" },
    { code: "+33" },
    { code: "+55" },
    { code: "+86" },
    { code: "+7"},
    { code: "+82" },
    { code: "+39" },
    { code: "+34"},
    { code: "+63" },
    { code: "+65"},
    { code: "+27"},
    { code: "+92" },
    { code: "+880" },
    { code: "+20" },
    { code: "+66" },
    { code: "+60" },
    { code: "+52" },
    { code: "+46" },
    { code: "+41" },
    { code: "+31"},
    { code: "+32" },
    { code: "+48" },
    { code: "+353" },
    { code: "+47" },
    { code: "+90" },
    { code: "+43" },
    { code: "+351" },
    { code: "+372"},
    { code: "+380" },
    { code: "+58" },
        // Add more country codes as needed
    ];

 const [contactInfo, setContactInfo] = useState(null);


   

useEffect(() => {
    const fetchContactInfo = async () => {
        try {
            const response = await fetchcontactdetails();
            const data = response.data;
            if (data && data.length > 0) {
                setContactInfo(data[0]); // Using the first entry from the API response
            }
        } catch (error) {
            console.error('Error fetching contact info:', error);
        }
    };

    fetchContactInfo();
}, []);
    // Handling input changes for both English and Arabic fields
    const handleChange = (e) => {
        const { name, value } = e.target;

        if (name === "firstName" || name === "lastName" || name === "message") {
            setFormData((prevData) => ({
                ...prevData,
                [name]: { ...prevData[name], en: value }
            }));
        } else {
            setFormData((prevData) => ({
                ...prevData,
                [name]: value
            }));
        }
    };

    // Handling country code change
    const handleCountryCodeChange = (e) => {
        setFormData((prevData) => ({
            ...prevData,
            countryCode: e.target.value
        }));
    };

    // Validate input fields
    const validateForm = () => {
        const newErrors = {
            firstName: formData.firstName.en === '',
            lastName: formData.lastName.en === '',
            email: formData.email === '',
            phone: formData.phone && formData.phone.trim() === '', // Only validate phone if provided
            message: formData.message.en === ''
        };
        setErrors(newErrors);

        // Check if there are any errors
        return Object.values(newErrors).every((error) => !error);
    };

    // Handling form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) {
            return; // Don't submit the form if there are errors
        }

        // Construct the data object to be sent in the POST request
        const submissionData = {
            firstName: formData.firstName.en, // Send only the English value
            lastName: formData.lastName.en,   // Send only the English value
            email: formData.email,
            phone: formData.phone ? `${formData.countryCode} ${formData.phone}` : '', // Only include phone if provided
            message: formData.message.en, // Send only the English value
        };

        try {
            // Making POST request to the API with form data
            const response = await axios.post(CONTACT_API_URL, submissionData, {
                headers: {
                    'Content-Type': 'application/json', // Ensure the content-type is application/json
                },
            });
            console.log('Form submitted successfully:', response.data);
            // Handle success (e.g., show a success message, reset form, etc.)
             setFormData({
                firstName:  { en: '', ar: '' },
                lastName:  { en: '', ar: '' },
                email: '',
                phone: '',
                message:  { en: '', ar: '' },
            }); // Clear form fields
        } catch (error) {
            console.error('Error submitting form:', error);
            // Handle error (e.g., show an error message)
        }
    };

    return (
        <>
            <div className="container my-4" >
                {/* Row for Cards */}
                <div className="row mt-5" >
                    <div className="col-md-8"  dir={language === "en" ? "ltr" : "rtl"} >
                        <form className="p-5" id="bigbox" style={{ backgroundColor: '#0B1A40', padding: '20px' }} onSubmit={handleSubmit}>
                            <div style={{ display: 'flex' }}>
                                {/* Horizontal line on the left */}
                                <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                                {/* Contact Us text in the middle */}
                                <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '18px', lineHeight: "33.73px", fontWeight: "700" }}>
                                    {language === "en" ? <>Contact Us</> : <>تواصل معنا</>}
                                </h2>
                                {/* Horizontal line on the right */}
                                <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                            </div>
                            <h2 style={{ color: 'white', fontSize: '36px', lineHeight: "67.47px", fontWeight: "700" }}>
                                {language === "en" ? <>Get In Touch With Us Today!</> : <>ابقى على تواصل </>}
                            </h2>
                            

                            {/* Form fields */}
                            <div className="form-row d-flex mb-4">
                                <div className="form-group col-md-6 mx-2">
                                    <label htmlFor="firstName" className="name">
                                        {language === "en" ? <>First Name</> : <>الاسم الأول </>}
                                    </label>
                                    <input
                                        type="text"
                                        className={`form-control box ${errors.firstName ? 'border-danger' : ''} inputstyle`}
                                        id="firstName"
                                        name="firstName"
                                        value={formData.firstName.en}
                                        onChange={handleChange}
                                         dir={language === "en" ? "ltr" : "rtl"} 
                                        placeholder={language === "en" ? "John" : "جون"}
                              
                                    />
                                </div>
                                <div className="form-group col-md-6 mx-2">
                                    <label htmlFor="lastName" className="name">
                                        {language === "en" ? <>Last Name</> : <>الاسم الأخير </>}
                                    </label>
                                    <input
                                        type="text"
                                        className={`form-control box ${errors.lastName ? 'border-danger' : ''} inputstyle`}
                                        id="lastName"
                                        name="lastName"
                                        value={formData.lastName.en}
                                        onChange={handleChange}
                                         dir={language === "en" ? "ltr" : "rtl"} 
                                        placeholder={language === "en" ? "Doe" : "ظبية"}
                                       
                                    />
                                </div>
                            </div>

                            <div className="form-row d-flex mb-4">
                                <div className="form-group col-md-6 mx-2">
                                    <label htmlFor="email" className="name">
                                        {language === "en" ? <>Email Address</> : <>البريد الالكتروني</>}
                                    </label>
                                    <input
                                        type="email"
                                        className={`form-control box ${errors.email ? 'border-danger' : ''} inputstyle`}
                                        id="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                         dir={language === "en" ? "ltr" : "rtl"} 
                                        placeholder={language === "en" ? "yourname@example.com" : "البريد الالكتروني "}
                                       
                                    />
                                </div>
                                <div className="form-group col-md-6 mx-2">
                                    <label htmlFor="phone" className="name">
                                        {language === "en" ? <>Phone (Optional)</> : <>رقم التلفون ( اختياري) </>}
                                    </label>
                                    <div className="d-flex">
                                        {/* Country Code and Phone Number Combined */}
                                        <select
                                            className="form-control  phonecontrol1 "
                                            name="countryCode"
                                            dir="ltr"
                                            value={formData.countryCode}
                                            onChange={handleCountryCodeChange}
                                          
                                        >
                                            {countryCodes.map((code) => (
                                                <option key={code.code} value={code.code}>
                                                    {code.label} {code.code}
                                                </option>
                                            ))}
                                        </select>
                                        <input
                                            type="text"
                                            className={`form-control ${errors.phone ? 'border-danger' : '' } phonecontrol2` }
                                            name="phone"
                                            value={formData.phone}
                                            onChange={handleChange}
                                            placeholder={language === "en" ? "Enter your phone number" : "ادخل رقم هاتفك"}
                                              dir={language === "en" ? "ltr" : "rtl"} 
                                           
                                        />
                                    </div>
                                </div>
                            </div>

                          <div className="form-row mb-4">
    <div className="form-group col-12 mx-2">
        <label htmlFor="message" className="name">
            {language === "en" ? <>Message</> : <>رسالة</>}
        </label>
        <textarea
            className={`form-control box2 pt-5 ${errors.message ? 'border-danger' : ''} inputstyle`}
            id="message"
            name="message"
            value={formData.message.en}
            onChange={handleChange}
             dir={language === "en" ? "ltr" : "rtl"} 
            placeholder={language === "en" ? "Leave your message here..." : "اترك رسالة "}
            rows="5"
           
        ></textarea>
    </div>
</div>

                            <div>
                                <button type="submit" className="btn btn-dark cbutton rounded-pill d-flex align-items-center mx-auto">
                                    <span style={{ fontSize: '16px', lineHeight: "29.98px", fontWeight: "500" }}>
                                        {language === "en" ? <>Submit Message</> : <>ارسل</>}
                                    </span>
                                    <i className="bi bi-arrow-right ml-2" style={{ paddingLeft: "10px" }}></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    

                       {/* Cards for services */}
                    <div className="col-lg-3 col-md-6 col-sm-12" dir={language === "en" ? "ltr" : "rtl"} >
                        <div className="mb-4 contact">
                            <div className="card text-white box3">
                                <div className="card-body">
                                    <div className="d-flex align-items-center mb-3">
                                        {/* Thumbnail Image */}
                                        <div>
                                            <img src="./image/Vector (2).png" alt="Thumbnail" style={{ width: '50px', height: '60px', marginRight: '15px',marginBottom:'30px', objectFit: "contain" }} />
                                        </div>
                                        {/* Title and Info */}
                                        <div className="textspace">
                                           <h5 className="card-title IFGameStudio" > 
    {language === "en" ? "IF Game Studio" : "استديو اي اف للاعاب الالكترونية "}
</h5>

                                             <p style={{ fontFamily: 'Cairo', color: '#8EABE5', marginBottom: '5px', fontSize: '18px', fontWeight: "300" }}>
        {contactInfo?.Address?.[language]}
    </p>
                                          <a 
    href={contactInfo?.maplink} 
    style={{ textDecoration: 'none' }} 
    target="_blank" 
    rel="noopener noreferrer"
>
   {language==="en"?"Direction":"التعليمات"}    
</a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>




                        {/* Additional Cards */}
                        <div className="mb-4 contact">
                            <div className="card text-white box3">
                                <div className="card-body">
                                    <div className="d-flex align-items-center mb-3">
                                        {/* Thumbnail Image */}
                                        <div>
                                            <img src="./image/Vector (3).png" alt="Thumbnail" style={{ width: '50px', height: '60px', marginRight: '15px', objectFit: "contain" }} />
                                        </div>
                                        {/* Contact Info */}
                                        <div className="textspace">
                                            <h5 className="card-title" style={{ fontSize: '22px', lineHeight: "41.23px", fontWeight: "700" }}>{language==="en"?"Call Us":" تواصل معنا "   }</h5>
                                            <h6 className="card-text" dir="ltr" style={{ fontFamily: 'Cairo', color: '#8EABE5', fontSize: '18px', fontWeight: "300" }}><a
      href={`tel:${contactInfo?.mobile1}`}
      style={{ color: '#8EABE5', textDecoration: 'none' }}
    >
      {contactInfo?.mobile1}
    </a></h6>
                                            <h6 className="card-text" dir="ltr" style={{ fontFamily: 'Cairo', color: '#8EABE5', fontSize: '18px', fontWeight: "300" }}> <a
      href={`tel:${contactInfo?.mobile2}`}
      style={{ color: '#8EABE5', textDecoration: 'none' }}
    >
      {contactInfo?.mobile2}
    </a></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="mb-4 contact">
                            <div className="card text-white box3">
                                <div className="card-body">
                                    <div className="d-flex align-items-center mb-3">
                                        {/* Thumbnail Image */}
                                        <div>
                                            <img src="./image/Vector (4).png" alt="Thumbnail" style={{ width: '50px', height: '60px', marginRight: '15px', objectFit: "contain" }} />
                                        </div>
                                        {/* Contact Info */}
                                        <div className="textspace">
                                            <h5 className="card-title" style={{ fontSize: '22px', lineHeight: "41.23px", fontWeight: "700" }}>{language==="en"?"Email":"البريد الالكتروني"   }</h5>
                                            <h6 className="card-text" dir="ltr" style={{ fontFamily: 'Cairo', color: '#8EABE5', fontSize: '18px', fontWeight: "300" }}>
                                              <a
      href={`mailto:${contactInfo?.email}`}
      style={{ color: '#8EABE5', textDecoration: 'none' }}
    >
      {contactInfo?.email}
    </a>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
              <div className="container d-flex justify-content-center my-5">
                <iframe className="map"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7242.671852915162!2d46.636398745795475!3d24.818183111827437!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee40eefcb6a9d%3A0xbc4308498520f827!2sAnas%20Ibn%20Malik%20Rd%2C%20Riyadh%20Saudi%20Arabia!5e0!3m2!1sen!2sin!4v1731161730419!5m2!1sen!2sin"
                    referrerPolicy="no-referrer-when-downgrade"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                ></iframe>
            </div>
        </>
    );
}

export default Contact2;
