import React, { useEffect, useState } from 'react';
import "./Header.css";
import {  fetchcontactdetails,IMAGE_URL } from "../../api/api";


function Header({language}) {
    const [contactData, setContactData] = useState(null);
   

    useEffect(() => {
        // Fetch data from the API
        const fetchData = async () => {
            try {
                const response = await fetchcontactdetails();
                const data = response.data;
                setContactData(data[0]); // Assuming you're using the first object in the array
            } catch (error) {
                console.error("Error fetching contact data:", error);
            }
        };
        fetchData();
    }, []);

    return (
        <>
            {/* Hero Section */}
            <div 
                style={{
                    position: 'relative',
                    backgroundImage: `url(${contactData ? `${IMAGE_URL}${contactData.image}` : '/placeholder.jpg'})`, 
                    backgroundSize: 'cover',  
                    backgroundPosition: 'center', 
                    height: '90vh', 
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                    color: 'white',
                }}
            >
                <div 
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1,
                    }}
                />
                <div style={{ position: 'relative', zIndex: 2 }}>
                    <h3 style={{ color: '#00FFCC', fontWeight: "700", fontSize: "25px", lineHeight: "24px" }}>IF-GAMES</h3> 
                    <h1 className='header-image'> {language === "en" ? "Contact Us" : "تواصل معنا"}</h1>
                </div>
            </div>
        </>
    );
}

export default Header;
