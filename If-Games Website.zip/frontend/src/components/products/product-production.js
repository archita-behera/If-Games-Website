import React, { useEffect, useState } from 'react';
import axios from 'axios';

function ProductProduction() {
    const [product, setProduct] = useState(null);
    const apiUrl = 'https://apis.vnvision.in/api/'; 

    useEffect(() => {
        const fetchProduct = async () => {
            try {
                const response = await axios.get(apiUrl);
                // Assuming your API returns an array of products and you want the first one
                setProduct(response.data[0]);
            } catch (error) {
                console.error('Error fetching product data:', error);
            }
        };

        fetchProduct();
    }, []);

    if (!product) {
        return <p style={{ color: 'white' }} ></p>;
    }

    return (
        <>
            <div className='text-center mb-4'>
                <h2 style={{ color: 'white' }}>In Production</h2>
            </div>

            <div className="container p-5 Procontener">
                <div className="row">
                    <div className='col-md-12 d-flex flex-column flex-md-row align-items-start'>
                        <div className="text-center text-md-left mb-3 mb-md-0 ">
                            <div className='productionheader-imagebox'>
                                <img
                                    src={product.imageUrl} // Assuming imageUrl is a property in your API response
                                    className='production-img1'
                                    alt={product.name} // Assuming name is a property in your API response
                                />
                            </div>
                        </div>

                        <div className="flex-grow-1">
                            <div style={{ marginLeft: "25px", marginBottom: "-20px" }} className="productionfooter-para">
                                <h3 style={{ fontSize: "36px", color: "white", fontFamily: "Cairo", fontWeight: "700" }}>{product.name}</h3>
                                <p style={{ fontSize: "16px", color: "white", fontFamily: "Cairo", fontWeight: "600" }}>Expected Launch:<span>{product.expectedLaunch}</span></p> {/* Assuming expectedLaunch is a property */}
                            </div>

                            <p className="production-para p-3 p-md-4">
                                {product.description} {/* Assuming description is a property */}
                            </p>
                        </div>

                        {/* Image positioned at the bottom-right */}
                        <div className="col-md-1 d-flex justify-content-end">
                            <img className='Proimg'
                                src="./image/g18-removebg-preview 1.png"
                                alt="Game Preview"
                            />
                        </div>
                    </div>

                    {/* Centered Follow Button inside the container */}
                    <div className="col-md-12 d-flex justify-content-center ">
                        <button type="button" className="btn btn-outline-light rounded-pill Probutton">Follow</button>
                    </div>
                </div>
            </div>
        </>
    );
}

export default ProductProduction;
