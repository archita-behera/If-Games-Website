import React from 'react';
import './product.css';

function Pbody() {
    return (
        <>
            {/* Section Heading */}
            <div className="text-center mt-5">
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {/* Horizontal line on the left */}
                    <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />

                    {/* OUR PRODUCTS text in the middle */}
                    <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '28px' }}>OUR PRODUCTS</h2>

                    {/* Horizontal line on the right */}
                    <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />
                </div>
                <h2 style={{ color: 'white' }}>Released Game</h2>
            </div>
            <br />

            {/* Container for the image and the card */}
            <div className="container my-4 position-relative">

                {/* Image on top of the card */}
                <img
                    className='img'
                    src="image/p-1.png"
                    alt="Loading"
                    style={{
                        width: '100%',
                        maxWidth: '466px',
                        height: 'auto',
                        position: 'absolute',
                        top: '-50px', // Adjust this value for exact placement
                        left: '76%',  // Adjust this value to move the image horizontally
                        transform: 'rotate(17.52deg)',
                        zIndex: 9  // Ensure the image is above the card
                    }}
                />

                {/* Left Image Section */}
                <div className="row position-relative mt-5 product-card">
                    <div className="col-12 col-md-4">
                        <img
                            className='img2'
                            src="image/g3.png"
                            alt=""
                            style={{
                                width: "100%",
                                maxWidth: "445px",
                                height: "auto",
                                borderRadius: '24px 0px 0px 0px',
                                marginRight: '30px',
                            }}
                        />
                    </div>

                    {/* Card Section */}
                    <div className="col-12 col-md-8">
                        <div className="card pcard text-white" style={{ backgroundColor: '#16182D', borderRadius: '15px', border: '2px solid #303030', marginLeft: '50px', zIndex: 2 }}>
                            <div className="card-body p-3 ps-5">
                                <h3 className="card-title">LASER RUSH</h3>
                                <h6>Launched in: 2019</h6>
                                <p className='P'>This adventure combines advanced graphics and innovative gameplay mechanics. As a flagship release in our series, Laser Rush paves the way for a variety of diverse and exciting gaming experiences currently in production at the studio.</p>
                                <p className='P-2'>This adventure combines advanced graphics and innovative gameplay mechanics. As a flagship release in our series, Laser Rush paves the way for a variety of diverse and exciting gaming experiences currently in production at the studio.</p>

                                <div className="d-flex align-items-center mt-5">
                                    {/* Social Icons */}
                                    <img src="./image/icons8-microsoft-48 1.png" alt="Game Preview" />
                                    <img src="./image/icons8-playstore-48 1.png" alt="Game Preview" />

                                    {/* "Play Game" Button */}
                                    <button type="button" className="btn pbtn btn-outline-light justify-content-end rounded-pill ms-auto">Play Game</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Cards Section */}
                <div className="row mt-4 product-card">
                    <div className="col-12 col-md-8">
                        <div className="card pcard pcard2 text-white" style={{ backgroundColor: '#16182D', borderRadius: '15px', border: '2px solid #303030', marginLeft: '50px', zIndex: 2 }}>
                            <div className="card-body p-3 ps-5">
                                <h3 className="card-title">LASER RUSH</h3>
                                <h6>Launched in: 2019</h6>
                                <p className='P'>This game was produced for Waffle Village Co. where the character of Novu collects as much waffles as possible to achieve the highest score.</p>
                                <p className='P-3'>This game was produced for Waffle Village Co. where the character of Novu collects as much waffles as possible to achieve the highest score.</p>

                                <div className="d-flex align-items-center mt-3">
                                    {/* Social Icons */}
                                    <img src="./image/icons8-microsoft-48 1.png" alt="Game Preview" />
                                    <img src="./image/icons8-playstore-48 1.png" alt="Game Preview" />

                                    {/* "Play Game" Button */}
                                    <button type="button" className="btn pbtn btn-outline-light justify-content-end rounded-pill ms-auto">Play Game</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="col-12 col-md-4">
                        <img
                            className='img2'
                            src="image/g6 (2).png"
                            alt="mjbj"
                            style={{
                                width: "100%",
                                maxWidth: "445px",
                                height: "auto",
                                borderRadius: '24px 0px 0px 0px',
                                marginRight: '30px',
                            }}
                        />
                    </div>
                </div>
            </div>
        </>
    );
}

export default Pbody;