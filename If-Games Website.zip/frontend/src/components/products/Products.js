import React, { useState, useEffect } from "react";
import Pheader from "./Pheader";
import ProductProduction from "./product-production";
import Pbody2 from "./Pbody2";
import Pbody2mobile from "./Pbody2mobile";

function Products({ language }) {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    window.addEventListener('resize', handleResize);

    // Cleanup listener on component unmount
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return (
    <>
      <Pheader language={language} />
      {isMobile ? (
        <Pbody2mobile language={language} />
      ) : (
        <Pbody2 language={language} />
      )}
      <br/><br/><br/>
      <ProductProduction />
    </>
  );
}

export default Products;
