import React, { useEffect, useState } from 'react';
import styles from './Pbody2mobile.module.css';
import { fetchproducts, IMAGE_URL } from '../../api/api';

function Pbody2mobile({ language }) {
  const [products, setProducts] = useState([]);
  const [currentAudio, setCurrentAudio] = useState(null);

  useEffect(() => {
    loadProducts();

    // Cleanup function to stop audio on component unmount
    return () => {
      if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0; // Reset audio to the beginning
      }
    };
  }, [currentAudio]);

  const loadProducts = async () => {
    try {
      const res = await fetchproducts();
      setProducts(res.data);
    } catch (err) {
      console.error('Error fetching products:', err);
    }
  };

  const handlePlayAudio = (audioPath) => {
    // Pause previous audio if playing
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0; // Reset audio to the beginning
    }

    const audio = new Audio(`${IMAGE_URL}${audioPath}`);
    audio.play().catch((error) => {
      console.error('Error playing audio:', error);
    });
    setCurrentAudio(audio);
  };

  if (!products) {
    return <p style={{ color: 'white' }}>Loading...</p>;
  }

  return (
    <>
      <div className={styles.textCenter}>
        <div className={styles.headerLine}>
          <hr className={styles.hrLine} />
          <h2 className={styles.headerText}>
            {language === 'en' ? 'OUR PRODUCTS' : 'منتجاتنا'}
          </h2>
          <hr className={styles.hrLine} />
        </div>
        <h2 className={styles.subHeading}>
          {language === 'en' ? 'Released Game' : ' الالعاب المنشورة'}
        </h2>

        <div className={`${styles.container} position-relative`} >
          <img className={styles.topImage} src="image/p-1.png" alt="Loading" />

          {products.map((product, index) => (
            <div key={index} className={`${styles.row} row position-relative product-card`}>
              {index % 2 === 0 ? (
                <>
                  <div className="col-12 col-md-4">
                    {/* Check if the product has a video */}
                    {product.video ? (
                      <video
                        className={`${styles.img2} img-fluid`}
                        src={`${IMAGE_URL}${product.video}`}
                        alt={product.title}
                        controls
                        muted
                        style={{ borderRadius: '24px' }}
                        onMouseEnter={(e) => {
                          e.target.play();  
                          e.target.muted = false;
                        }}
                        onMouseLeave={(e) => {
                          e.target.pause();  
                          e.target.currentTime = 0; 
                          e.target.muted = true; 
                        }}
                      />
                    ) : (
                      <img
                        className={`${styles.img2} img-fluid`}
                        src={`${IMAGE_URL}${product.image}`}
                        alt={product.title}
                        onMouseEnter={() => handlePlayAudio(product.audio)}
                     onMouseLeave={() => {
                          currentAudio.pause() 
                        }}
                        style={{ borderRadius: '24px' }}
                      />
                    )}
                  </div>
                  <div className="col-12 col-md-8" >
                    <div className={`${styles.card2} pcard text-white`}>
                      <div className="card-body  p-3 ps-5" dir={language === "en" ? "ltr" : "rtl"}>
                        <div className={styles.pcardtitle} >
                          <h3 className={styles.cardtitle}>
                            {product.title?.[language] || 'Title'}
                          </h3>
                          <h6 className={styles.subtitle}>
                            {product.subtitle?.[language] || 'Subtitle'}
                          </h6>
                        </div>
                       <p dir={language === "en" ? "ltr" : "rtl"}
  className={styles.P}
  dangerouslySetInnerHTML={{
    __html: product.description?.[language] || '<p>Description</p>',
  }}
></p>

                        <div className={`align-items-center marginicons mt-5`} >
                          <a href={`${product.appStoreLink}`} >
                            <img
                              src="./image/app-store-icon.png"
                              alt="App Store"
                              height="30"
                              width="30"
                            />
                          </a>
                          <a href={`${product.playStoreLink}`}>
                            <img
                              src="./image/icons8-playstore-48 1.png"
                              alt="Play Store"
                              height="30"
                              width="30"
                            />
                          </a>
                          <button
                            type="button"
                            className={`${styles.pbtn} btn btn-outline-light rounded-pill ms-auto`}
                          >
                            {language === 'en' ? 'Play Game' : 'العب اللعبة'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  <div className="col-12 col-md-6 order-2 order-md-1" >
                    <div className={`${styles.card} pcard text-white`}>
                      <div className="card-body p-3 ps-5"dir={language === "en" ? "ltr" : "rtl"}>
                        <div className={styles.pcardtitle}>
                          <h3 className={styles.cardtitle}>
                            {product.title?.[language] || 'Title'}
                          </h3>
                          <h6 className={styles.subtitle}>
                            {product.subtitle?.[language] || 'Subtitle'}
                          </h6>
                        </div>
                      <p  className={styles.P} dir={language === "en" ? "ltr" : "rtl"}
                         dangerouslySetInnerHTML={{
                              __html: product.description?.[language] || '<p>Description</p>',
                                                                                          }}
                              ></p>

                        <div className={`  marginicons mt-5`} >
                          <a href={`${product.appStoreLink}`} >
                            <img
                              src="./image/app-store-icon.png"
                              alt="App Store"
                              height="30"
                              width="30"
                            />
                          </a>
                          <a href={`${product.playStoreLink}`}>
                            <img
                              src="./image/icons8-playstore-48 1.png"
                              alt="Play Store"
                              height="30"
                              width="30"
                            />
                          </a>
                          <button
                            type="button"
                            className={`${styles.pbtn} btn btn-outline-light rounded-pill ms-auto`}
                          >
                            {language === 'en' ? 'Play Game' : 'العب اللعبة'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-4 order-1 order-md-2">
                    {/* Check if the product has a video */}
                    {product.video ? (
                       <video
                        className={`${styles.img3} img-fluid`}
                        src={`${IMAGE_URL}${product.video}`}
                        alt={product.title}
                        controls
                        muted
                        style={{  borderRadius: '24px' }}
                        onMouseEnter={(e) => {
                          e.target.play();  
                          e.target.muted = false; 
                        }}
                        onMouseLeave={(e) => {
                          e.target.pause(); 
                          e.target.currentTime = 0; 
                          e.target.muted = true; 
                        }}
                      />

                    ) : (
                      <img
                        className={`${styles.img3} img-fluid`}
                        src={`${IMAGE_URL}${product.image}`}
                        alt={product.title}
                        onMouseEnter={() => handlePlayAudio(product.audio)}
                         onMouseLeave={() => {
                          currentAudio.pause() 
                        }}
                        style={{ paddingLeft: '60px', borderRadius: '24px' }}
                      />
                    )}
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Pbody2mobile;
