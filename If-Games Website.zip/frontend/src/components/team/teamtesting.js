import React, { useState } from "react";
import "./teamtesting.css";

function OTeam() {
  const [hoveredImage, setHoveredImage] = useState(null);

  const teamMembers = [
    { src: "/image/Mohammed 1.png", name: "Mohammed", role: "CEO", info: "Successfully expanded Apple's product lineup, and revenue and Apple Services" },
    { src: "/image/Component 7.png", name: "Noorah", role: "Project Manager", info: "Your leadership guides us forward" },
    { src: "/image/Component 8.png", name: "Reemma", role: "Game Designer", info: "Your creativity brings our worlds to life" },
    { src: "/image/Component 11.png", name: "Hanadi", role: "Training Program Consultant", info: "Empowering teams with knowledge" },
    { src: "/image/Component 10.png", name: "Waad", role: "Game Artist", info: "Creating visuals that captivate" },
    { src: "/image/Component 9.png", name: "Hanan", role: "Developer", info: "Code that turns dreams into reality" },
  ];

  return (
    <div className="container-fluid p-3">
      <div className="row justify-content-center">
        <div className="text-center">
          <a
            style={{
              fontSize: "1.5rem",
              textDecoration: "none",
              fontSize: "25px",
              lineHeight: "24px",
              fontWeight: "600",
              color: "#00FFCC",
            }}
          >
            ---OUR TEAM---
          </a>
          <h2 style={{ color: "white", fontSize: "36px", lineHeight: "38.4px", fontWeight: "700" }}>Our CEO</h2>

          <div className="col-12 d-flex justify-content-center">
            <div
              className="d-flex justify-content-center align-items-center flex-column"
              style={{
                position: "relative",
                overflow: "hidden",
                width: hoveredImage === teamMembers[0].name ? "200px" : "120px",
                height: hoveredImage === teamMembers[0].name ? "300px" : "150px",
                transition: "all 0.3s ease",
              }}
              onMouseEnter={() => setHoveredImage(teamMembers[0].name)}
              onMouseLeave={() => setHoveredImage(null)}
            >
              <img
                src={teamMembers[0].src}
                alt="CEO"
                style={{
                  width: hoveredImage === teamMembers[0].name ? "100px" : "120px",
                  height: hoveredImage === teamMembers[0].name ? "130px" : "150px",
                  objectFit: "contain",
                  transform: hoveredImage === teamMembers[0].name ? "scale(0.9)" : "scale(1)",
                  transition: "transform 0.3s ease, width 0.3s ease, height 0.3s ease",
                  backgroundColor: "#16182D",
                }}
              />
              {hoveredImage === teamMembers[0].name && (
                <div
                  style={{
                    marginTop: "10px",
                    color: "white",
                    textAlign: "center",
                    transition: "opacity 0.4s ease",
                    opacity: 1,
                    backgroundColor: "#16182D",
                  }}
                >
                  <h4>{teamMembers[0].name}</h4>
                  <h5>{teamMembers[0].role}</h5>
                  <p>{teamMembers[0].info}</p>
                </div>
              )}
            </div>
          </div>

          <h2 style={{ color: "white", fontSize: "36px", lineHeight: "38.4px", fontWeight: "700" }}>Our Development Team</h2>

          {/* Wrapper for sliding functionality on mobile */}
          <div className="slider-container">
            <div className="slider d-flex">
              {teamMembers.slice(1).map((member, index) => (
                <div
                  key={index}
                  className="position-relative d-flex flex-column align-items-center card"
                  style={{
                    margin: "30px",
                    width: hoveredImage === member.name ? "200px" : "120px",
                    height: hoveredImage === member.name ? "300px" : "150px",
                    transition: "all 0.3s ease",
                    backgroundColor: "#16182D",
                  }}
                  onMouseEnter={() => setHoveredImage(member.name)}
                  onMouseLeave={() => setHoveredImage(null)}
                >
                  <img
                    src={member.src}
                    alt={member.name}
                    style={{
                      width: hoveredImage === member.name ? "100px" : "120px",
                      height: hoveredImage === member.name ? "130px" : "150px",
                      transform: hoveredImage === member.name ? "scale(0.9)" : "scale(1)",
                      transition: "transform 0.3s ease",
                    }}
                  />
                  {hoveredImage === member.name && (
                    <div
                      style={{
                        marginTop: "10px",
                        color: "white",
                        textAlign: "center",
                        transition: "opacity 0.3s ease",
                        opacity: 1,
                      }}
                    >
                      <h4>{member.name}</h4>
                      <h5>{member.role}</h5>
                      <p>{member.info}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default OTeam;
