import React ,{useState,useEffect} from "react";


import Header from "./Theader";
import About from "./About";
import OurTeam from "../home/OurTeam";
import TeamMember from "../home/OurTeam-mob-res";
import OTeam from "./teamtesting";



// api implimented in this section

function Teams({language}) {

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    useEffect(() => {
        const handleResize = () => {
          setIsMobile(window.innerWidth <= 768);
        };
        window.addEventListener('resize', handleResize);

        // Cleanup listener on component unmount
        return () => {
          window.removeEventListener('resize', handleResize);
        };
      }, []);
  return (
    <>
    
      <Header language={language}/>
      <About language={language}/>
      {/* <OTeam/> */}
      
 {isMobile ? (
  <TeamMember language={language}/>
        
      ) : (
        <OurTeam language={language}/>
      )}
      
      
      <br></br>
      <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br> <br></br>
    </>
  );
}

export default Teams;