import React, { useEffect, useState } from "react";
import "./About.css";
import {fetchheroimg , IMAGE_URL} from "../../api/api"

function About({ language }) {
    const [description, setDescription] = useState('');

    useEffect(() => {
        // Fetch data from the API
        fetchheroimg()
            .then((response) => response.data)
            .then((data) => {
                // Find the object with the specific ID
                const teamData = data.find(item => item._id === '673b30e9f9c2566fca4adc17');
                if (teamData) {
                    // Set the description based on the selected language
                    setDescription(language === "en" ? teamData.description.en : teamData.description.ar);
                }
            })
            .catch((error) => console.error('Error fetching description:', error));
    }, [language]);

    return (
        <>
            <div className="container p-3" dir={language === "en" ? "ltr" : "rtl"}>
                <div className="row p-5">
                    <div className="col-12">
                        {/* Center-align the heading */}
                        <div className="text-center">
                            <div className="pb-5 d-flex align-items-center justify-content-center">
                                {/* Horizontal line on the left */}
                                <hr className="heading-line" />

                                {/* ABOUT OUR TEAM text in the middle */}
                                <h2
                                    className="heading-text"
                                    style={{ fontSize: '25px', lineHeight: "24px", fontWeight: "600" }}
                                >
                                    {language === "en" ? "ABOUT OUR TEAM" : "عن فريقنا"}
                                </h2>

                                {/* Horizontal line on the right */}
                                <hr className="heading-line" />
                            </div>
                        </div>

                        {/* Display fetched description */}
                        <p className="paragraph" style={{ lineHeight: "24px", fontWeight: "400" }}>
                            {description}
                        </p>

                  
                    </div>
                </div>
            </div>
        </>
    );
}

export default About;
