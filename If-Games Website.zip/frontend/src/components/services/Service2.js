import React, { useEffect, useState } from 'react';
import styles from './Service2.module.css';
import droneLogo from '../../assets/droneLogo.png';
import GameArt from '../../assets/gameArt.png';
import { fetchservices,IMAGE_URL} from '../../api/api';

function Service2({ language }) {
  const [services, setServices] = useState([]);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const res = await fetchservices();
      setServices(res.data);
    } catch (err) {
      console.error("Error loading services:", err);
    }
  };

  if (!services.length) {
    return <p style={{ color: 'white' }}>Loading...</p>;
  }

  return (
    <>
      {/* Section Heading */}
      <div className={styles.container} dir={language === "en" ? "ltr" : "rtl"}>
        <div className="text-center mt-5">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />
            <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '28px' }}>
              {language === "en" ? "Our Services" : "خدماتنا"}
            </h2>
            <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />
          </div>
        </div>
        <br />
        <div className={styles.our_services}>
          <div>
            <img src={droneLogo} alt="Drone logo" className={styles.drone_logo} />
          </div>
          <div className={styles.first_section}>
            <div className={styles.card_section}>
              {services.map((service) => (
                <div className={styles.service_card} key={service._id}>
                  <div className={styles.image}>
                    <img
                      src={`${IMAGE_URL}${service.image || GameArt}`}
                      alt={service.title?.[language] || service.title.en}
                      className={styles.IFGame}
                    />
                  </div>
                  <div className={styles.title[language]}>
                    <h6 className={styles.h6}>
                      {service.title?.[language] || service.title.en}
                    </h6>
                    <p
                      className={styles.servicedescription}
                      dangerouslySetInnerHTML={{
                        __html: service.longDescription?.[language] || service.longDescription.en,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Service2;
