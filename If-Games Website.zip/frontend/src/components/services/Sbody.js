import React, { useEffect, useState } from 'react';
import { fetchservices,IMAGE_URL } from '../../api/api';
import droneLogo from '../../assets/droneLogo.png';
import GameArt from '../../assets/gameArt.png';
import GameDevelopment from '../../assets/GameDevelopment.jpeg';
import GameAnimation from '../../assets/GameAnimation.jpeg';
import './services.css';

function Sbody({ language }) {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const res = await fetchservices();
      setServices(res.data);
      setLoading(false); // Set loading to false after data is fetched
    } catch (err) {
      setError(err.message);
      setLoading(false); // Set loading to false on error
    }
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <>
      {/* Section Heading */}
      <div className="text-center mt-5" dir={language === "en" ? "ltr" : "rtl"} >
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />
          <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '28px' }}>
            {language === 'en' ? 'Our Services' : 'خدماتنا'}
          </h2>
          <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />
        </div>
      </div>
      <br />

      <div className='our_services p-5'>
        <div>
          <img src={droneLogo} alt='loading' className='drone_logo' style={{
            width: '550px',
            height: '600px',
            marginTop: "260px",
            top: '370px',
            left: '-9.39px',
            transform: 'rotate(-5.00deg)',
            zIndex: '9',
          }} />
        </div>
        <div className='first_section'>
          <div className='card_section'>
            {services.map((service) => (
              <div key={service._id} className='service-card'>
                <div className='title' dir={language === "en" ? "ltr" : "rtl"}>
                  <h6 className='service-title'>{service.title?.[language]||service.title.en}</h6>
                  {/* Render HTML directly */}
                  <p
                    className='service-description'
                    dangerouslySetInnerHTML={{ __html: service.longDescription?.[language] ||service.longDescription.en }}
                  />
                 
                </div>
                <div className='image'>
                  <img
                    src= {`${IMAGE_URL}${service.image || GameArt}`}
                    alt="Service"
                    className='service-image'
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br><br></br>
    </>
  );
}

export default Sbody;