import React, { useState, useEffect } from "react";
import { Carousel } from 'react-bootstrap';
import { fetchTestimonials, IMAGE_URL } from "../../api/api";  // Import the API function
import "./testimonials.css";

function Testimonials({ language }) {
  const [testimonials, setTestimonials] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const loadTestimonials = async () => {
      try {
        const response = await fetchTestimonials();  // Use the API function
        const data = response.data;

        // Format testimonials for different languages
        const formattedTestimonials = data.map((testimonial) => ({
          name: testimonial.name[language] || testimonial.name.en,  // Use language-specific name or fallback to English
          image: testimonial.image ? `${IMAGE_URL}${testimonial.image}` : "/image/default-profile.png",
          text: testimonial.message[language] || testimonial.message.en,  // Use language-specific message or fallback to English
          rating: testimonial.rating || 5,
        }));

        setTestimonials(formattedTestimonials);
      } catch (error) {
        console.error("Error fetching testimonials:", error);
      }
    };

    loadTestimonials();
  }, [language]);  // Trigger the effect when language changes

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  if (testimonials.length === 0) {
    return <div>Loading testimonials...</div>;
  }

  return (
    <div className="container testimonial-container my-4 p-2" dir={language === "en" ? "ltr" : "rtl"} >
      <div className="text-center testimonial-header mb-3">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
          <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '25px', lineHeight: "24px", fontWeight: "600" }}>
            {language === "en" ? "TESTIMONIALS" : "آراء العملاء"}
          </h2>
          <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
        </div>
        <h2 className="mb-5" style={{ color: "white", fontSize: '36px', lineHeight: "38.4px", fontWeight: "700" }}>
          {language === "en" ? "What Clients Say About Us" : "ماذا قالوا عنا عملائنا"}
        </h2>
      </div>

      <div className="row justify-content-center position-relative testimonial-container">
        <div className="col-md-8 col-lg-6 mb-3 position-relative">
          <div className="card text-white testimonial-card" style={{ borderRadius: '0px', backgroundColor: '#16182D' }}>
            <div className="card-body">
              <div className="d-flex flex-column flex-md-row align-items-center align-items-md-start mb-3">
                <Carousel controls={false} indicators={false} interval={1500}>
                  <Carousel.Item>
                    <img
                      src={testimonials[currentIndex].image}
                      alt={testimonials[currentIndex].name}
                      style={{ width: "150px", height: "150px", marginBottom: '15px', marginRight: "15px", borderRadius: '50%' }}
                      className="img-fluid"
                    />
                     <div className="rating ml-auto star-center">
                  {[...Array(Math.floor(testimonials[currentIndex].rating))].map((_, i) => (
                    <i key={i} className="bi bi-star-fill text-warning"></i>
                  ))}
                  {testimonials[currentIndex].rating % 1 !== 0 && (
                    <i className="bi bi-star-half text-warning"></i>
                  )}
                </div>
                  </Carousel.Item>
                </Carousel>
                <div dir={language === "en" ? "ltr" : "rtl"}>
                  <h5 className="card-title mt-md-4">{testimonials[currentIndex].name}</h5>
                  <p className="card-text" style={{ color: "gray" }}>
                    {testimonials[currentIndex].text}
                  </p>
                </div>
              </div>

              <div className="d-flex justify-content-between">
                <div></div>
               
              </div>
            </div>
          </div>

          {/* Arrows for larger screens */}
          <i
            className="bi bi-chevron-left position-absolute d-none d-md-block"
            style={{
              fontSize: "2rem",
              color: "white",
              top: "50%",
              left: "-20px",
              cursor: "pointer"
            }}
            onClick={prevTestimonial}
          ></i>

          <i
            className="bi bi-chevron-right position-absolute d-none d-md-block"
            style={{
              fontSize: "2rem",
              color: "white",
              top: "50%",
              right: "-20px",
              cursor: "pointer"
            }}
            onClick={nextTestimonial}
          ></i>

          {/* Centered arrows for small screens in rounded buttons */}
          <div className="d-md-none d-flex justify-content-center mt-3">
            <button
              className="btn btn-outline-light rounded-circle mx-2 d-flex align-items-center justify-content-center"
              style={{
                fontSize: "1.5rem",
                width: "3rem",
                height: "3rem",
                padding: 0
              }}
              onClick={prevTestimonial}
            >
              <i className="bi bi-chevron-left"></i>
            </button>
            <button
              className="btn btn-outline-light rounded-circle mx-2 d-flex align-items-center justify-content-center"
              style={{
                fontSize: "1.5rem",
                width: "3rem",
                height: "3rem",
                padding: 0
              }}
              onClick={nextTestimonial}
            >
              <i className="bi bi-chevron-right"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Testimonials;
