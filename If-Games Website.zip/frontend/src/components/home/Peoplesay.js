import React from 'react';

function Peoplesay() {
    return (
        <div className="container my-4 p-2"  dir={language === "en" ? "ltr" : "rtl"}>
            {/* Header Section */}
            <div className='text-center mb-3'>
                <a style={{ color: 'blue' }}>---TESTIMONIALS---</a>
                <h2 style={{ color: 'white' }}>What People Say About Us</h2>
            </div>

            {/* Arrows and Cards Section */}
            <div className="d-flex align-items-center justify-content-between">
                {/* Left Circular Arrow with margin */}
                <div className="arrow-circle me-3" style={circleStyle}>
                    <i className="bi bi-chevron-left" style={arrowStyle}></i>
                </div>

                {/* Cards Row */}
                <div className="row flex-nowrap" style={{ overflowX: 'auto' }}>
                    {/* Card 1 */}
                    <div className="col-md-4">
                        <div className="card text-white mb-3" style={{ backgroundColor: '#04041a' }}>
                            <div className="card-body text-center">
                                <img src="./images/Rectangle 36.png" alt="Span2" />
                                <h5 className="card-title mt-2">Rana</h5>
                                <p className="card-text ProPara" >
                                    Our vision is to redefine gaming boundaries by establishing new standards and creating inspiring and educational entertainment experiences.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Card 2 */}
                    <div className="col-md-4">
                        <div className="card text-white mb-3" style={{ backgroundColor: '#04041a' }}>
                            <div className="card-body text-center">
                                <img src="./images/Rectangle 30.png" alt="Span2" />
                                <h5 className="card-title mt-2">Ruba</h5>
                                <p className="card-text" style={{ color: 'gray' }}>
                                    Our vision is to redefine gaming boundaries by establishing new standards and creating inspiring and educational entertainment experiences.
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Card 3 */}
                    <div className="col-md-4">
                        <div className="card text-white mb-3" style={{ backgroundColor: '#04041a' }}>
                            <div className="card-body text-center">
                                <img src="./images/Rectangle 29.png" alt="Span2" />
                                <h5 className="card-title mt-2">Rana</h5>
                                <p className="card-text" style={{ color: 'gray'  }}>
                                    Our vision is to redefine gaming boundaries by establishing new standards and creating inspiring and educational entertainment experiences.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Right Circular Arrow with margin */}
                <div className="arrow-circle ms-3" style={circleStyle}>
                    <i className="bi bi-chevron-right" style={arrowStyle}></i>
                </div>
            </div>
        </div>
    );
}

// CSS for the circular arrow
const circleStyle = {
    width: '50px',
    height: '50px',
    borderRadius: '50%',
    backgroundColor: '#333',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    cursor: 'pointer',
};

const arrowStyle = {
    fontSize: '2rem',
    color: 'grey',
};

export default Peoplesay;