import React, { useEffect, useState } from 'react';
import './Production.css';
import { fetchproducts, IMAGE_URL } from '../../api/api';

function Production({ language }) {
    const [product, setProduct] = useState(null);
//   const id = "672c97cab927e1d1571d0ca3"
    useEffect(() => {
        async function fetchProductData() {
            try {
                const response = await fetchproducts();
                 const data = response.data;

        if (data && Array.isArray(data)) {
          const response = data.find(item => item._id === "672c97cab927e1d1571d0ca3");
                          setProduct(response);

        }
            } catch (error) {
                console.error("Error fetching product data:", error);
            }
        }

        fetchProductData();
    }, []);

    if (!product) {
        return <div>Loading...</div>;
    }

    // Safely access properties with fallback
    const title = product?.title?.[language] || "N/A";
    const subtitle = product?.subtitle?.[language] || "N/A";
    const description = product?.description?.[language] || "N/A";

    return (
        <>
            <div className='text-center mb-4' >
                <h2 style={{ color: 'white' }}>
                    {language === "en" ? "In Production" : "العاب تحت التطوير"}
                </h2>
            </div>

            <div className="container p-5 Procontener"  dir={language === "en" ? "ltr" : "rtl"}>
                <div className="row">
                    <div className='col-md-12 d-flex flex-column flex-md-row align-items-start'>
                        {/* Product Header */}
                        <div className="text-center text-md-left mb-3 mb-md-0">
                            <div className='productionheader-imagebox'>
                                <img
                                    src={`${IMAGE_URL}/${product.logo1}`}
                                    className='production-img1'
                                    alt={title}
                                />
                                <h3 className='Yazan marginleftyazan'>{title}</h3>
                                <p className='Expected-Launch marginleftyazan'>{subtitle}</p>
                            </div>
                        </div>
<div className="flex-grow-1 productionparamargin">
  <div
    className="production-para"
    dir={language === "en" ? "ltr" : "rtl"}
    dangerouslySetInnerHTML={{ __html: description }}
  ></div>
</div>


                        {/* Bottom-right Image */}
                        <div
                            className=" productionimg d-flex justify-content-end"
                           
                        >
                            <img
                                className='Proimg'
                                src={`${IMAGE_URL}/${product.image}`}
                                alt="Game Preview"
                            />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Production;
