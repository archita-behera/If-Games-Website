import React, { useEffect, useState } from 'react';
import { Carousel } from 'react-bootstrap';
import { fetchservices } from '../../api/api';
import { Link } from 'react-router-dom';
import './Ourservise-card.css';
import './Header.css';

const CardCarousel = ({ language = 'en' }) => {
  const [services, setServices] = useState([]);

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await fetchservices();
        setServices(response.data);
      } catch (error) {
        console.error('Error fetching services:', error);
      }
    };

    fetchServices();
  }, []);

  return (
    <div className="container mt-5">
      {/* Carousel with slide effect */}
      <Carousel interval={3000} indicators={false} controls={true}>
        {services.map((service, index) => (
          <Carousel.Item key={service._id}>
            <div className="d-flex justify-content-center">
              <div className="card gameart-card text-white">
                <div className="card-body">
                  {/* Display title and description based on selected language */}
                  <h3 className="card-title" >
                    {service.title?.[language] || service.title.en}
                  </h3>
                  <p dangerouslySetInnerHTML={{ __html: service.shortDescription?.[language] || service.shortDescription.en }} />
                   <Link to="/services">
                  <button type="button" className="btn btn-outline-light rounded-pill gameart-button">
                    {language === "en" ? "Explore More" : "اكتشف المزيد"}
                  </button>
                     </Link>
                </div>
              </div>
            </div>
          </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
};

export default CardCarousel;
