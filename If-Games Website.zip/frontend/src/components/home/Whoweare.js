import React, { useState, useEffect } from 'react';
import './Header.css'; // Update CSS with responsive styles
import { fetchmissionvision, IMAGE_URL } from "../../api/api";

function Whoweare({ language }) {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(false);

    useEffect(() => {
        const fetchMissionVisionData = async () => {
            try {
                const response = await fetchmissionvision();
                const result = response.data;
                if (result && result.data && result.data.length > 0) {
                    setData(result.data[0]);
                } else {
                    setError(true);
                }
            } catch (err) {
                setError(true);
            } finally {
                setLoading(false);
            }
        };
        fetchMissionVisionData();
    }, []);

    if (loading) {
        return <p style={{ color: 'white', textAlign: 'center' }}>Loading...</p>;
    }

    if (error) {
        return <p style={{ color: 'red', textAlign: 'center' }}>Failed to load data. Please try again.</p>;
    }

    return (
        <div
            className="container p-3"
            style={{ backgroundColor: '#090A1A' }}
            dir={language === "en" ? "ltr" : "rtl"}
        >
            <div className="row p-2">
               <div className="text-center col-12">
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                        <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '25px', fontWeight: "600" }}>
                            {language === "en" ? "WHO WE ARE" : "من نحن "}
                        </h2>
                        <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                    </div>
                    <h2 className='if-gamesTitle' style={{ color: 'white', marginTop: '20px', fontSize: "36px", fontWeight: "700" }}>
                        {language === "en" ? "What Sets IF-Games Apart?" : "لماذا اي اف استيديو"}
                    </h2>
                    <p className='wp' style={{ fontWeight: "400", textAlign: "center", fontSize: "18px" }} dir={language === "en" ? "ltr" : "rtl"}>
                        {language === "en" ? data.heading.en : data.heading.ar}
                    </p>
                </div>


                <div className="col-lg-9 col-md-12 margintop">
                    <div className="inline-item d-flex flex-column flex-lg-row align-items-center mb-3">
                          <div className="mcc">
                            <img src={`${IMAGE_URL}${data.image1}`} className='vision-image imgm' alt="Vision" />
                        </div>
                        <div className="ms-3 visionmargin">
                            <h3 className='vision' style={{ color: 'white' }} dir={language === "en" ? "ltr" : "rtl"}>
                                {language === "en" ? "Vision" : "رؤية"}
                            </h3>
                            <p className="wp2">
                                {language === "en" ? data.description.en : data.description.ar}
                            </p>
                        </div>
                    </div>

                    <div className="inline-item d-flex flex-column flex-lg-row align-items-center mb-3">
                       <div className="mcc">
                            <img src={`${IMAGE_URL}${data.image2}`} alt="Mission" className='mission-image imgm' />
                        </div>
                        <div className="ms-3 visionmargin">
                             <h3 className='vision' style={{ color: 'white' }} dir={language === "en" ? "ltr" : "rtl"}>
                                {language === "en" ? "Mission" : "مهمة"}
                            </h3>
                            <p className="wp2">
                                {language === "en" ? data.description1.en : data.description1.ar}
                            </p>
                        </div>
                    </div>
                </div>

                <div className="col-lg-3 col-md-12 text-center position-relative">
                    <div className="backgroundgame"></div>
                    <img src={`${IMAGE_URL}${data.image3}`} className="img-fluid game mb-4" alt="Rocket" />
                </div>
            </div>
        </div>
    );
}

export default Whoweare;
