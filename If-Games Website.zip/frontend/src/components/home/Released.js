import React,{useState,useEffect} from 'react';
import './Released.css';
import Realesedcard from './Realeased-card';
import Realeasedcard2 from './Realeased-card2';


function Released({language}) {

    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    useEffect(() => {
        const handleResize = () => {
          setIsMobile(window.innerWidth <= 768);
        };
        window.addEventListener('resize', handleResize);

        // Cleanup listener on component unmount
        return () => {
          window.removeEventListener('resize', handleResize);
        };
      }, []);


    return (
        <div className="container my-4">
            {/* Header Section */}
            <div className='text-center'>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {/* Horizontal line on the left */}
                    <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                    {/* OUR GAMES text in the middle */}
                    <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '28px' }}>{language === "en"?(<>OUR GAMES</>):(<>العابنا</>)}</h2>
                    {/* Horizontal line on the right */}
                    <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                </div>
                <h2 style={{ color: 'white' }}>{language === "en"?(<>Released Games</>): (<>الالعاب المنشورة</>)}</h2>
            </div>


            {isMobile ? (
    <Realesedcard language={language}/>
        
      ) : (
        <Realeasedcard2 language={language}/>
      )}

            
        </div>
    );
}

export default Released;
