import React from "react";
function Ourservices() {
  return (
    <>
      <div className='text-center mt-4'>
                    <a style={{ color: 'blue' }}>---OUR SERVICES---</a>
                    <h2 style={{ color: 'white' }}>Game Art  And Development Services</h2>
                   
                </div>
      <div className="container text-center p-4" style={{backgroundColor:'black'}}>
        <div className="row ">
          <div className="col-md-4">
          <img src="images/Design.png" alt="" style={{ width: "25%" }} />{" "}
          <br /> <br />
            <h1 style={{color: 'white'}}>Game Art</h1>
            <p className="card-text">
              <ul style={{color: 'gray'}}>
                <li>
                  Concept Art: Transforming Ideas Into Captivating Visuals
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>2D Art: Designing Intricate Sprites and Environments</li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>3D Art: Creating Realistic Models and Animations</li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                  UI/UX Design: Developing Intuitive and Engaging Interfaces
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                  Game Animation: Producing Fluid and Dynamic Animations for
                  Characters and Environments
                </li>
              </ul>
            </p>
          </div>
          <div className="col-md-4 ">
          <img src="images/Game Controller.png" alt="" style={{ width: "25%" }} />{" "}
          <br /> <br />
            <h1 style={{color: 'white'}}>Game Development</h1>
            <p className="card-text">
              <ul style={{color: 'gray'}}>
                <li>
                  {" "}
                  Full Cycle Development: Handling Project from Concept to
                  Release
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                  Game Co-Development: Collaborating On Existing Projects Game
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                Porting: Adapting Games for Various Platforms
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                AR/VR Development:
              Crafting Immersive Experiences with Advanced Technology
                </li>
              </ul>

             
            </p>
          </div>
          <div className="col-md-4">
          <img src="images/Kermit The Frog.png" alt="" style={{ width: "25%" }} />{" "}
          <br /> <br />
            <h1 style={{color: 'white'}}>Game Animation</h1>
            <p className="card-text">
            <ul style={{color: 'gray'}}>
                <li>
                Character Animation: Creating Lifelike Movements and Expressions
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                Environmental Animation: Brining Game Worlds to Life with Dynamic
                </li>
              </ul>
              <ul style={{color: 'gray'}}>
                <li>
                Elements Cutscene Animation: Developing Cinematic Sequences to
                Enhance Storytelling.
                </li>
              </ul>
            </p>
          </div>
        </div>
       
      </div><div className='text-center'><button type="button" className="btn btn-outline-light rounded-pill " >Explore More</button>
      </div>
     
    </>
  );
}

export default Ourservices;