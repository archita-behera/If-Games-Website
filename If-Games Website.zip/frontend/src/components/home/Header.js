import React, { useState, useEffect } from 'react';
import './Header.css'; // Import custom CSS file for other styles
import { fetchslides, IMAGE_URL } from "../../api/api";

function Header({ language }) {
    const [slides, setSlides] = useState([]); // Store the slides
    const [currentSlideIndex, setCurrentSlideIndex] = useState(0); // Track the current slide index

    // Fetch slides from API on component mount
    useEffect(() => {
        const getSlides = async () => {
            try {
                const response = await fetchslides();
                setSlides(response.data); // Assuming response.data contains the slides array
            } catch (error) {
                console.error("Failed to fetch slides:", error);
            }
        };
        getSlides();
    }, []);

    // Slide transition logic
    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentSlideIndex((prevIndex) =>
                (prevIndex + 1) % slides.length // Loop back to the first slide after the last
            );
        }, 5000); // Change slide every 5 seconds

        return () => clearInterval(interval); // Clear interval on component unmount
    }, [slides]);

    // Only access the current slide if slides are available
    const currentSlide = slides.length > 0 ? slides[currentSlideIndex] : null;

    // If currentSlide is available, get the image, title, and headline, otherwise fallback to defaults
    const currentBackgroundImage = currentSlide ? `${IMAGE_URL}${currentSlide.image}` : '/image/home.png';
    const headerTitle = currentSlide ? currentSlide.title[language] : "IF-GAMES";
    const headerSubtitle = currentSlide ? currentSlide.headline[language] : "Infinite Worlds";
    const headerLine = currentSlide ? currentSlide.line[language] : "of Game Development";
    return (
        <>
            {/* Hero Section */}
            <div
                style={{
                    position: 'relative',
                    backgroundImage: `url('${currentBackgroundImage}')`,  // Dynamic background image
                    backgroundSize: 'cover',
                    backgroundPosition: 'center',
                    height: '90vh',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                    color: 'white',
                    transition: 'background-image 1s ease-in-out', // Smooth transition for slider
                }}
            >
                <div
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1,
                    }}
                />
                <div style={{ position: 'relative', zIndex: 2 }}>
                    <h3 style={{ color: '#00FFCC', fontWeight: "700", fontSize: "25px", lineHeight: "24px" }}>
                        {headerTitle}
                    </h3>
                    <h1 className='header-image' style={{ lineHeight: '1.2', whiteSpace: 'pre-line' }}>
                        {headerSubtitle}
                    </h1>
                     <h1 className='header-image' style={{ lineHeight: '1.2', whiteSpace: 'pre-line' }}>
                        {headerLine}
                    </h1>
                </div>
            </div>
        </>
    );
}

export default Header;
