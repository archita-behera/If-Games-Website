// import React from 'react';
// import './Ourclient.css';
// import {fetchclient} from "../../api/api"

// function Ourclient({language}) {
//     return (
//         <div className="container-fluid mt-5 our-client-section">
//             <div className="text-center mb-3">
//                 <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
//           <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
//           <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '25px', lineHeight: "24px", fontWeight: "600" }}>{language==="en"?(<>OUR CLIENTS</>):(<>عملاؤنا</>)}</h2>
//           <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
//         </div>
//                 <h2 className="mb-5" style={{ color: "white", fontSize: '36px', lineHeight: "38.4px", fontWeight: "700" }}>{language==="en"?(<>Who We Work With?</>):(<>مع من نعمل؟</>)}</h2>
//             </div>

//             <div className="client-logos-wrapper">
//                 <div className="client-logos">
//                     <img src="./image/image 1 3.png" alt="Client 1" className="client-logo " />
//                     <img src="./image/image 4 1.png" alt="Client 2" className="client-logo " />
//                     <img src="./image/image 5 1.png" alt="Client 3" className="client-logo " />
                    
//                 </div>
//                 <div className="client-logos duplicate">
//                     <img src="./image/image 1 3.png" alt="Client 1" className="client-logo " />
//                     <img src="./image/image 4 1.png" alt="Client 2" className="client-logo " />
//                     <img src="./image/image 5 1.png" alt="Client 3" className="client-logo " />
                    
//                 </div>
//             </div>
//         </div>
//     );
// }

// export default Ourclient;



// api connected code


import React, { useState, useEffect } from 'react';
import './Ourclient.css';
import { fetchclient ,IMAGE_URL} from "../../api/api";

function Ourclient({ language }) {
    const [clients, setClients] = useState([]);

    useEffect(() => {
        const loadClients = async () => {
            try {
                const response = await fetchclient();
                setClients(response.data); // Assuming response.data contains the list of clients
            } catch (error) {
                console.error("Error fetching clients:", error);
            }
        };
        loadClients();
    }, []);

    return (
        <div className="container-fluid mt-5 our-client-section">
            <div className="text-center mb-3">
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                    <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '25px', lineHeight: "24px", fontWeight: "600" }}>
                        {language === "en" ? "OUR CLIENTS" : "عملائنا"}
                    </h2>
                    <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
                </div>
                <h2 className="mb-5" style={{ color: "white", fontSize: '36px', lineHeight: "38.4px", fontWeight: "700" }}>
                    {language === "en" ? "Who We Work With?" : "نعمل مع "}
                </h2>
            </div>

            <div className="client-logos-wrapper">
                <div className="client-logos">
                    {clients.map((client, index) => (
                        <img
                            key={index}
                            src={`${IMAGE_URL}${client.image}`} // Assuming each client object has an imageUrl field
                            alt={client.name || `Client ${index + 1}`}
                            className="client-logo"
                        />
                    ))}
                </div>
                <div className="client-logos duplicate">
                    {clients.map((client, index) => (
                        <img
                            key={index}
                            src={`${IMAGE_URL}${client.image}`}
                            alt={client.name || `Client ${index + 1}`}
                            className="client-logo"
                        />
                    ))}
                </div>
            </div>
        </div>
    );
}

export default Ourclient;

