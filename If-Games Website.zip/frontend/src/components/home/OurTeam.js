import React, { useEffect, useState } from "react";
import "./OurTeam.css";
import { fetchTeam, IMAGE_URL } from "../../api/api";

function OurTeam({language}) {
  const [teamMembers, setTeamMembers] = useState([]);
  const [hoveredImage, setHoveredImage] = useState(null);

  useEffect(() => {
    loadTeam();
  }, []);

  const loadTeam = async () => {
    try {
      const res = await fetchTeam();
      console.log("Team data:", res.data); // Debugging log to check the team data structure
      setTeamMembers(res.data);
    } catch (err) {
      console.error("Error fetching teams:", err);
    }
  };

  // Helper function to split teamMembers into rows of 5
  const getRows = (members) => {
    const rows = [];
    for (let i = 1; i < members.length; i += 5) {
      rows.push(members.slice(i, i + 5));
    }
    return rows;
  };

  return (
    <div className="container-fluid p-3">
      <div className="row justify-content-center">
        <div className="text-center">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
            <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '25px', lineHeight: "24px", fontWeight: "600" }}>{language==="en"?(<>OUR TEAMS</>):(<>فريقنا</>)}</h2>
            <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
          </div>
          <h2 style={{ color: "white", fontSize: "36px", fontWeight: "700", }}>
          {language==="en"?(<>Our CEO</>):(<>الرئيس التنفيذي</>)}
            
          </h2>

          {teamMembers.length > 0 && (
            <div className="col-12 d-flex justify-content-center">
              <div
                className="d-flex justify-content-center align-items-center flex-column"
                style={{
                  position: "relative",
                  overflow: "hidden",
                  width: hoveredImage === teamMembers[0].name ? "200px" : "120px",
                  height: hoveredImage === teamMembers[0].name ? "335px" : "150px",
                  transition: "all 0.3s ease",
                  backgroundColor:' rgb(22, 24, 45)',
                }}
                onMouseEnter={() => setHoveredImage(teamMembers[0].name)}
                onMouseLeave={() => setHoveredImage(null)}
              >
                <img
                  src={`${IMAGE_URL}${teamMembers[0].image}`}
                  alt="CEO"
                  style={{
                    width: hoveredImage === teamMembers[0].name ? "100px" : "120px",
                    height: hoveredImage === teamMembers[0].name ? "130px" : "150px",
                    objectFit: "cover",
                    transform: hoveredImage === teamMembers[0].name ? "scale(0.9)" : "scale(1)",
                    transition: "transform 0.3s ease, width 0.3s ease, height 0.3s ease",
                    backgroundColor: "#16182D",
                  }}
                />
                {hoveredImage === teamMembers[0].name && (
                  <div style={{ marginTop: "10px", color: "white", textAlign: "center", backgroundColor: "#16182D" }}>
                    <h4>{teamMembers[0].name?.[language] || teamMembers[0].name.en}</h4>
                   
                    <p>{teamMembers[0].bio?.[language] || teamMembers[0].bio.en}</p>
                     <p>{teamMembers[0].position?.en || "did't assigned"}</p>
                    <a href={`https://${teamMembers[0].linkedinlink}`}  target="_blank" rel="noopener noreferrer">
                        <img src="./image/icons8-linkedin-94 1.png" alt="LinkedIn" style={{ width: "24px", height: "24px", color: "#0077B5" }} />
                      </a>
                  </div>
                )}
              </div>
            </div>
          )}

          <h2 className="mt-4" style={{ color: "white", fontSize: "36px", fontWeight: "700" }}>
          {language==="en"?(<>Our Development Team</>):(<>فريق التطوير التقني </>)}
            
          </h2>

          {getRows(teamMembers).map((row, rowIndex) => (
            <div key={rowIndex} className="d-flex justify-content-center" style={{ gap: "70px", marginBottom: "20px", marginTop: "16px" }}>
              {row.map((member, index) => (
                <div
                  key={index}
                  className="position-relative d-flex flex-column align-items-center"
                  style={{
                    width: hoveredImage === member.name ? "200px" : "120px",
                    height: hoveredImage === member.name ? "300px" : "150px",
                    transition: "all 0.3s ease",
                    backgroundColor: "#16182D",
                    marginTop: "50px",
                  }}
                  onMouseEnter={() => setHoveredImage(member.name)}
                  onMouseLeave={() => setHoveredImage(null)}
                >
                  <img
                    src={`${IMAGE_URL}${member.image}`}
                    alt={member.name.en}
                    style={{
                      width: hoveredImage === member.name ? "100px" : "120px",
                      height: hoveredImage === member.name ? "130px" : "150px",
                      transform: hoveredImage === member.name ? "scale(0.9)" : "scale(1)",
                      transition: "transform 0.3s ease",
                    }}
                  />
                  {hoveredImage === member.name && (
                    <div style={{ marginTop: "10px", color: "white", textAlign: "center" }}>
                      <h4>{member.name?.[language] || member.name.en}</h4>
                       <p>{member.position?.[language]  || "not asigned"}</p>
                      <p>{member.bio?.[language] || member.bio.en}</p>
                     
                      <a href={`https://${member.linkedinlink}`}  target="_blank" rel="noopener noreferrer">
                        <img src="./image/icons8-linkedin-94 1.png" alt="LinkedIn" style={{ width: "24px", height: "24px", color: "#0077B5" }} />
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default OurTeam;
