import React ,{useState,useEffect}from "react";
import './Header.css';
import CardCarousel from "./Ourservise-card"
import Card from "./Card";




function Ourservice({language}) {
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    useEffect(() => {
        const handleResize = () => {
          setIsMobile(window.innerWidth <= 768);
        };
        window.addEventListener('resize', handleResize);

        return () => {
          window.removeEventListener('resize', handleResize);
        };
      }, []);


    return (
        <div className="container my-4">
            <div className="row p-3">
                {/* Section Heading */}
                <div className="text-center mb-3">
                    <div  className="ourservices-headertext">
                        {/* Horizontal line on the left */}
                        <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' ,marginLeft:"50%" }} />
                        
                        {/* OUR SERVICES text in the middle */}
                        <h2 style={{ color: '#00FFCC', margin: '0 10px', fontSize: '25px', fontWeight:"600" }}>{language === "en"?(<>OUR SERVICES</>) : (<>خدماتنا </>)}</h2>

                        {/* Horizontal line on the right */}
                        <hr style={{ width: '4%', borderColor: '#F9F9F9', borderWidth: '4px' }} />
                    </div>
                    <h2 style={{ color: 'white' ,fontSize: '36px', fontWeight:"700"  }}>{language === "en"?(<>Game Art And Development Services</>) :(<>خدمات تطوير الألعاب الالكترونية </>)} </h2>
                </div>

                {/* Left Image Section */}
                <div className="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <img src="./image/g17 2.png" className="img-fluid gameart-img" alt="Rocket" style={{objectFit:"cover"}}/>
                </div>

                {/* Right Cards Section */}
                <div className="col-lg-6 col-md-6 col-sm-12">
 

     
 
 {isMobile ? (
    <CardCarousel language={language}/>
        
      ) : (
        <Card language={language}/>
      )}


</div>
    </div>

</div>


           
       
    );
}

export default Ourservice;
