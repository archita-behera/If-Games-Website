import React,{useState,useEffect} from "react";
import Team from "./OurTeam-mob-res";
import Header from "./Header";
import Whoweare from "./Whoweare";
import Ourclient from "./Ourclient";
import Production from "./Production";
import Ourservices from "./Ourservices";
import Peoplesay from "./Peoplesay";
import Released from "./Released";
import OurTeam from "./OurTeam";
import Ourservice from "./Ourservice";
import Testimonials from "./Testimonials";



function Hero({language}) {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    useEffect(() => {
        const handleResize = () => {
          setIsMobile(window.innerWidth <= 768);
        };
        window.addEventListener('resize', handleResize);

        // Cleanup listener on component unmount
        return () => {
          window.removeEventListener('resize', handleResize);
        };
      }, []);
  return (
    <>
    <Header language={language}/>
    <Whoweare language={language}/>
    <Ourservice language={language}/>
    <Released language={language}/>  
    <Production language={language}/>
     
     <Ourclient language={language}/>
     <Testimonials language={language}/>
     
     {/*<Ourservices/>
     
     
     <Peoplesay/> */}
          
 {isMobile ? (
  <Team language={language}/> ) : (
        <OurTeam language={language}/>
      )}
    
    </>
  );
}

export default Hero;