import React, { useEffect, useState } from 'react';
import { Carousel } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Released.css';
import { Link } from "react-router-dom";
import { fetchproducts, IMAGE_URL } from '../../api/api'; // Import the fetchProducts function

function Realesedcard({ language }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch data from the API using the fetchProducts function from config
    fetchproducts()
      .then((response) =>  {
        setProducts(response.data.slice(0, 2));
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  return (
    <>
      <div className="container mt-5 releases-card" style={{ marginLeft: "24px" }} >
        {/* Carousel only visible on mobile screens */}
        <div className="d-lg-none"> {/* This div is only visible on screens smaller than large */}
          <Carousel interval={3000} indicators={false} controls={true}>
            {products.map((product, index) => (
              <Carousel.Item key={index}>
                <div className="card text-white released-container" style={{ border: 'none', backgroundColor: '#16182D', borderRadius: '0' }}>
                  <div className="card-body">
                    <div className="d-flex align-items-center mb-3">
                      <div>
                        <img dir={language === "en" ? "ltr" : "rtl"}
                          className="released-img"
                          src={`${IMAGE_URL}${product.logo1}`} // Using the IMAGE_URL from config
                          alt="Game Thumbnail"
                          style={{ width: '50px', height: '50px', marginRight: '15px' }}
                        />
                      </div>
                      <div >
                        <h5 dir={language === "en" ? "ltr" : "rtl"} className="card-title" dir={language === "en" ? "ltr" : "rtl"}>{product.title[language]}</h5>
                        <h6 dir={language === "en" ? "ltr" : "rtl"} className="card-text"dir={language === "en" ? "ltr" : "rtl"}>{product.subtitle[language]}</h6>
                      </div>
                    </div>

                  <p dir={language === "en" ? "ltr" : "rtl"}
                       className="card-text released-para"
                       style={{ fontSize: '18px' }}
                       dangerouslySetInnerHTML={{
                       __html: product.description?.[language]?.length > 200
                       ? `${product.description[language].substring(0, 200)}...`
                        : product.description[language] || product.description.en,
                            }}
                           />


                    <button dir={language === "en" ? "ltr" : "rtl"}
                      type="button"
                      className="btn btn-dark btn-sm mb-1 rounded-pill"
                      style={{ backgroundColor: "black", color: "#9CA0D2" }}
                    >
                      <span style={{ color: "#9CA0D2" }}>Downloads</span>{" "}
                      <span style={{ color: "white" }}>69k</span>
                    </button>

                    <div className="d-flex align-items-center mt-2" >
                      <a href={product.appStoreLink} target="_blank" rel="noopener noreferrer">
                        <img src="./images/app-store-icon.png" alt="Game Preview" style={{ marginRight: "2px", width: "33px", height: "33px" }} />
                      </a>
                      <a href={product.playStoreLink} target="_blank" rel="noopener noreferrer">
                        <img src="./image/icons8-playstore-48 1.png" alt="Game Preview" style={{ marginRight: "2px" }} />
                      </a>

                      <div className="d-flex justify-content-end" style={{ position: 'absolute', bottom: '20px', right: '20px' }}>
                        <img className="released-img" src={`${IMAGE_URL}${product.logo2}`} alt="Game Preview" style={{ width: '100px', height: '100px' }} />
                      </div>
                      <Link to="/products">
                        <button type="button" className="btn btn-outline-light rounded-pill ms-2">
                          Know More
                        </button>
                      </Link>
                    </div>
                  </div>
                </div>
              </Carousel.Item>
            ))}
          </Carousel>
        </div>
      </div>
    </>
  );
}

export default Realesedcard;
