import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { fetchproducts, IMAGE_URL } from '../../api/api'; // Import API function and IMAGE_URL
import './Released.css';

function Realeasedcard2({ language }) {
  const [games, setGames] = useState([]); // State to store fetched data

  useEffect(() => {
    // Fetch the data using fetchproducts
    fetchproducts()
      .then((response) => {
        // Limit to first 2 games from the API response
        setGames(response.data.slice(0, 2));
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []); // Empty dependency array ensures the data is fetched only once when the component mounts

  return (
    <>
      {/* Row for Cards */}
      <div className="row mt-5 realesedcardstyle" style={{ width: '1170px', height: '409px', margin:' 0 auto', }}  dir={language === "en" ? "ltr" : "rtl"}>
        {games.map((game, index) => (
          <div className="col-md-6 col-sm-12 mb-3" key={index}>
            {/* Card */}
            <div className="card text-white released-container" style={{ border: 'none', backgroundColor: '#16182D', borderRadius: '0' }}>
              <div className="card-body" style={{ width: '541px', height: '369px' }}>
                <div className="d-flex align-items-center mb-3">
                  {/* Thumbnail Image */}
                  <div>
                    <img dir={language === "en" ? "ltr" : "rtl"}
                      src={`${IMAGE_URL}${game.logo1}`} // Using dynamic image URL from IMAGE_URL
                      alt="Game Thumbnail"
                      style={{ width: '50px', height: '50px', marginRight: '15px' }}
                    />
                  </div>
                  {/* Title and Launch Info */}
                  <div className="cardrtl" dir={language === "en" ? "ltr" : "rtl"}>
                    <h5 className="card-title" style={{ fontWeight: '700', fontSize: '30px', lineHeight: '28.8px' }}>
                      {language === 'en' ? game.title.en : game.title.ar}
                    </h5>
                    <h6 className="card-text" style={{ fontWeight: '600', fontSize: '16px', lineHeight: '19.2px' }}>
                      {language === 'en' ? game.subtitle.en : game.subtitle.ar}
                    </h6>
                  </div>
                </div>

                <p dir={language === "en" ? "ltr" : "rtl"}
                  className="card-text released-para1"
                  style={{ fontWeight: '400', fontSize: '18px', lineHeight: '18px' }}
                  dangerouslySetInnerHTML={{
                    __html: game.description?.[language]?.length > 200
                      ? `${game.description[language].substring(0, 200)}...`
                      : game.description[language] || game.description.en,
                  }}
                />

                {/* Downloads button */}
                <button dir={language === "en" ? "ltr" : "rtl"}
                  type="button"
                  className="btn btn-dark btn-sm mb-1 rounded-pill"
                  style={{ backgroundColor: 'black', color: '#9CA0D2' }}
                >
                  <span style={{ color: '#9CA0D2' }}>Downloads</span>{' '}
                  <span style={{ color: 'white' }}>69k</span>
                </button>

                {/* Icons and "Know More" Button */}
                <div className="d-flex align-items-center mt-5">
                  {/* Social Icons */}
                  <a dir={language === "en" ? "ltr" : "rtl"} href={game.appStoreLink} target="_blank" rel="noopener noreferrer">
                    <img src="./images/app-store-icon.png" alt="Game Preview" style={{ marginRight: '10px', width: '33px', height: '33px' }} />
                  </a>

                  <a dir={language === "en" ? "ltr" : "rtl"} href={game.playStoreLink} target="_blank" rel="noopener noreferrer">
                    <img src="./image/icons8-playstore-48 1.png" alt="Game Preview" style={{ marginRight: '10px' }} />
                  </a>
                  <div className="d-flex justify-content-end imggame">
                    <img
                      src={`${IMAGE_URL}${game.logo2}`} // Dynamic game image
                      alt="Game Preview"
                      style={{ width: '185px', height: '180px', objectFit: 'contain' }}
                    />
                  </div>

                  {/* "Know More" Button */}
                  <Link to="/products">
                    <button type="button" className="btn btn-outline-light rounded-pill ms-2">
                      Know More
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

export default Realeasedcard2;
