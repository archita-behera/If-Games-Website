import React, { useState, useEffect } from 'react';
import { Carousel } from 'react-bootstrap';
import './OurTeam.css';
import { fetchTeam, IMAGE_URL } from '../../api/api';

const TeamMember = ({ src, name, role, bio, linkedInUrl, hoveredImage, setHoveredImage, language }) => (
  <div
    className="position-relative d-flex flex-column align-items-center"
    style={{
      margin: '30px',
      width: hoveredImage === name ? '200px' : '120px',
      height: hoveredImage === name ? '300px' : '150px',
      transition: 'all 0.3s ease',
      backgroundColor: '#16182D',
    }}
    onMouseEnter={() => setHoveredImage(name)}
    onMouseLeave={() => setHoveredImage(null)}
  >
    <img
      src={src}
      alt={name}
      style={{
        width: hoveredImage === name ? '100px' : '120px',
        height: hoveredImage === name ? '130px' : '150px',
        transform: hoveredImage === name ? 'scale(0.9)' : 'scale(1)',
        transition: 'transform 0.3s ease',
      }}
    />
    {hoveredImage === name && (
      <div
        style={{
          marginTop: '10px',
          color: 'white',
          textAlign: 'center',
          transition: 'opacity 0.3s ease',
          opacity: 1,
        }}
      >
        <h4>{name}</h4>
        <h5>{role}</h5>
        <p>{bio}</p>
        <a href={`https://${linkedInUrl}`} target="_blank" rel="noopener noreferrer">
          <img
            src="./image/icons8-linkedin-94 1.png"
            alt="LinkedIn"
            style={{ width: '24px', height: '24px' }}
          />
        </a>
      </div>
    )}
  </div>
);

const Team = ({ language }) => {
  const [hoveredImage, setHoveredImage] = useState(null);
  const [teamMembers, setTeamMembers] = useState([]);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    loadTeam();
  }, []);

  const loadTeam = async () => {
    try {
      const res = await fetchTeam();
      setTeamMembers(res.data);
    } catch (err) {
      console.error('Error fetching teams:', err);
    }
  };

  const handleSelect = (selectedIndex) => {
    setActiveIndex(selectedIndex);
  };

  return (
    <div className="container-fluid p-3">
      <div className="row justify-content-center">
        <div className="text-center">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
            <h2
              style={{
                color: '#00FFCC',
                margin: '0 10px',
                fontSize: '25px',
                lineHeight: '24px',
                fontWeight: '600',
              }}
            >
              {language === 'en' ? 'OUR TEAMS' : 'فريقنا'}
            </h2>
            <hr style={{ width: '4%', borderColor: '#00FFCC', borderWidth: '4px' }} />
          </div>
          <h2 style={{ color: 'white' }}>{language === 'en' ? 'Our CEO' : 'الرئيس التنفيذي'}</h2>

          {/* CEO's Component */}
          {teamMembers.length > 0 && (
            <div className="col-12 d-flex justify-content-center">
              <TeamMember
                src={`${IMAGE_URL}${teamMembers[0].image}`}
                name={teamMembers[0].name.en}
                role={teamMembers[0].position.en}
                bio={teamMembers[0].bio.en}
                linkedInUrl={teamMembers[0].linkedinlink}
                hoveredImage={hoveredImage}
                setHoveredImage={setHoveredImage}
                language={language}
              />
            </div>
          )}

          <h2 style={{ color: 'white' }}>
            {language === 'en' ? 'Our Development Team' : 'فريق التطوير التقني'}
          </h2>

          <div className="d-flex justify-content-center flex-wrap">
            {/* Carousel with Buttons */}
            <Carousel
              activeIndex={activeIndex}
              onSelect={handleSelect}
              controls={false}
              indicators={false}
              interval={null}
            >
              {teamMembers.slice(1).map((member, index) => (
                <Carousel.Item key={index}>
                  <TeamMember
                    src={`${IMAGE_URL}${member.image}`}
                    name={member.name.en}
                    role={member.position.en}
                    bio={member.bio.en}
                    linkedInUrl={member.linkedinlink}
                    hoveredImage={hoveredImage}
                    setHoveredImage={setHoveredImage}
                    language={language}
                  />
                </Carousel.Item>
              ))}
            </Carousel>
          </div>

          {/* Navigation Buttons */}
          <div className="d-flex justify-content-center mt-3" style={{ flexDirection: language === "en" ? "row" : "row-reverse" }}>
            {teamMembers.slice(1).map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                dir={language === "en" ? "ltr" : "rtl"}
                style={{
                  backgroundColor: activeIndex === index ? '#00FFCC' : '#16182D',
                  border: 'none',
                  margin: '0 5px',
                  width: '12px',
                  height: '12px',
                  borderRadius: '50%',
                  cursor: 'pointer',
                }}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Team;
