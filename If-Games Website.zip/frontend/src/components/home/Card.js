import React, { useEffect, useState } from 'react';
import { fetchservices,SERVICE_LINK  } from '../../api/api';
import { Link } from 'react-router-dom';
import './Header.css';

function Card({language}) {
  const [services, setServices] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const servicesPerPage = 3;

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const response = await fetchservices();
        setServices(response.data);
      } catch (error) {
        console.error('Error fetching services:', error);
      }
    };

    fetchServices();
  }, []);

  const indexOfLastService = currentPage * servicesPerPage;
  const indexOfFirstService = indexOfLastService - servicesPerPage;
  const currentServices = services.slice(indexOfFirstService, indexOfLastService);

  const nextPage = () => {
    if (currentPage < Math.ceil(services.length / servicesPerPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div className="server-card">
      {currentServices.map((service) => (
        <div className="mb-4" key={service._id}>
          <div className="card gameart-card text-white">
            <div className="card-body">
              <h3 className="card-title" style={{ fontSize: "36px", fontWeight: "700", lineHeight: "28.8px" }} dir={language === "en" ? "ltr" : "rtl"}>
                {service.title?.[language] || service.title.en}
              </h3>
              <p className='cardpara' dir={language === "en" ? "ltr" : "rtl"}>
                {service.shortDescription?.[language] || service.shortDescription.en}
              </p>
               <Link to="/services">
                <button type="button" className="btn btn-outline-light rounded-pill gameart-button">
                {language === "en"?(<>Explore More</>) : (<>اكتشف المزيد</>)}
                  
                </button>
                </Link>
            </div>
          </div>
        </div>
      ))}

      {/* Pagination Controls with Smaller Arrows */}
      {services.length > servicesPerPage && ( // Show only if there are more than `servicesPerPage` items
        <div className="pagination-controls text-center mt-4">
          <button onClick={prevPage} disabled={currentPage === 1} className="btn btn-outline-light me-2">
            <i className="fas fa-arrow-left fa-sm" style={{ fontSize: '0.75em' }}></i>
          </button>
          <button onClick={nextPage} disabled={currentPage >= Math.ceil(services.length / servicesPerPage)} className="btn btn-outline-light">
            <i className="fas fa-arrow-right fa-sm" style={{ fontSize: '0.75em' }}></i>
          </button>
        </div>
      )}
    </div>
  );
}

export default Card;