import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Footer.css";
import { fetchFooterImages, fetchSocialLinks, IMAGE_URL } from "../api/api";

function Footer({ language }) {
  const [footerImg, setFooterImg] = useState(null);
  const [socialLinks, setSocialLinks] = useState({});

  useEffect(() => {
    loadFooterImage();
    loadSocialLinks();
  }, []);

  const loadFooterImage = async () => {
    try {
      const response = await fetchFooterImages();
      setFooterImg(response.data);
    } catch (e) {
      console.log(e);
    }
  };

  const loadSocialLinks = async () => {
    try {
      const response = await fetchSocialLinks();
      const links = response.data.reduce((acc, item) => {
        switch (item._id) {
          case "6731a8dc9ae5d1b4f9e7fb81":
            acc.instagram = `https://${item.subtitle}`;
            break;
          case "6731a9309ae5d1b4f9e7fba0":
            acc.linkedin = `https://${item.subtitle}`;
            break;
          case "6731aa159ae5d1b4f9e7fbee":
            acc.x = `https://${item.subtitle}`;
            break;
          case "6734532c7059bcd8ece48e7a":
            acc.whatsapp = `https://${item.subtitle}`;
            break;
          default:
            break;
        }
        return acc;
      }, {});
      setSocialLinks(links);
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <>
      <div className="footer-content" style={{ display: "flex", justifyContent: "center", alignItems: "center", position: "relative" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", width: "90%", maxWidth: "1200px", padding: "20px", flexWrap: "wrap", transform: "translateX(-10%)" }}>
          <div style={{ marginBottom: "20px" }}>
            <img src={`${IMAGE_URL}${footerImg?.data[0]?.image}`} alt="Footer Background" style={{ maxWidth: "100%", height: "auto", marginLeft: "35px" }} />
          </div>

          <div className="footericon">
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", padding: "20px" }}>
              <img src="image/GameStudioLogo-removebg-preview 1.png" alt="Game Studio Logo" style={{ width: "159px", height: "92px" }} />
            </div>

            {/* Social Media Section */}
            <div className="socialmedia-container">
              {[
                { icon: "icons8-whatsapp-94 1.png", link: socialLinks.whatsapp },
                { icon: "icons8-linkedin-94 1.png", link: socialLinks.linkedin },
                { icon: "icons8-instagram-94 1.png", link: socialLinks.instagram },
                { icon: "icons8-twitterx-94.png", link: socialLinks.x },
              ].map((social, index) => (
                <a key={index} href={social.link || "#"} target="_blank" rel="noopener noreferrer" className="socialmediaicon-box">
                  <img src={`image/${social.icon}`} alt={social.icon} className="socialmedia-icons" />
                </a>
              ))}
            </div>

            {/* Navigation Links */}
            <div style={{ display: "flex", justifyContent: "center", gap: "40px", margin: "20px 0", flexWrap: "wrap" }}>
              <Link to="/contact" style={{ color: "white", cursor: "pointer", textDecoration: "none" }}>
                {language === "en" ? "Contact Us" : "تواصل معنا"}
              </Link>
              <Link to="/terms-and-conditions" style={{ color: "white", cursor: "pointer", textDecoration: "none" }}>
                {language === "en" ? "Terms & Conditions" : "الأحكام والشروط"}
              </Link>
              <Link to="/privacy-policy" style={{ color: "white", cursor: "pointer", textDecoration: "none" }}>
                {language === "en" ? "Privacy Policy" : "ساسية الخصوصية"}
              </Link>
            </div>

            {/* Footer Text */}
            <div>
              <p style={{ color: "gray", fontSize: "1.2rem", textAlign: "center" }}>
                ©2024 {language === "en" ? "All Rights Reserved By" : "جميع الحقوق محفوظة "} <span style={{ color: "white" }}>IF-Games</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Footer;
