// PrivacyPolicy.js
import React, { useEffect, useState } from "react";
import { fetchprivacy } from "../../api/api";  // Assuming your API functions are in an api.js file
import Policyheader from "./PolicyHeader";

function PrivacyPolicy({ language }) {
  const [privacyPolicyData, setPrivacyPolicyData] = useState(null);

  useEffect(() => {
    // Fetch Privacy Policy data when component mounts
    const fetchData = async () => {
      try {
        const response = await fetchprivacy();
        const data = response.data;

        if (data && Array.isArray(data)) {
          const privacyPolicy = data.find(item => item._id === "672f64ee04804dc4cab70088");
          setPrivacyPolicyData(privacyPolicy); // Set Privacy Policy data
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  if (!privacyPolicyData) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <Policyheader language={language} />
      <div className="container-fluid ps-5 p-3" dir={language === "en" ? "ltr" : "rtl"} style={{ backgroundColor: "#090A1A" }}>
        <div className="row p-lg-5 p-md-4 p-sm-3 p-2">
          <div className="col-12">
            {/* Center-align the heading */}
            <div className="text-center">
              <div className="heading-wrapper pb-5 d-flex justify-content-center align-items-center">
                <hr className="heading-line" />
                <h2 className="heading-text">
                  {language === "en" ? privacyPolicyData.title.en : privacyPolicyData.title.ar}
                </h2>
                <hr className="heading-line" />
              </div>
            </div>

            <div
              className="intro-text"
              dangerouslySetInnerHTML={{
                __html: language === "en" ? privacyPolicyData.description.en : privacyPolicyData.description.ar,
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default PrivacyPolicy;
