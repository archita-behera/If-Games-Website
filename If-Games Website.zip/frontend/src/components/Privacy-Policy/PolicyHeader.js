import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import '../home/Header.css'; // Import custom CSS file for other styles
import {fetchprivacy,IMAGE_URL} from "../../api/api"

function Policyheader({language}) {
    
     const [bannerImage, setBannerImage] = useState('');

useEffect(() => {
    fetchprivacy()
        .then(response => response.data)
        .then(data => {
            // Find the image with the specific ID
            const banner = data.find(item => item._id === '672f64ee04804dc4cab70088');
            if (banner) {
                setBannerImage(`${IMAGE_URL}${banner.image}`);
            }
        })
        .catch(error => console.error('Error fetching banner data:', error));
}, []);
    
    
    
    return ( 
        <>
           

            {/* Hero Section */}
            <div 
                style={{
                    className:"header-bgimg",
                    position: 'relative',
                  backgroundImage: `url(${bannerImage})`,
                    backgroundSize: 'cover',  
                    backgroundPosition: 'center', 
                    height: '100vh', 
                 
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    alignItems: 'center',
                    textAlign: 'center',
                    color: 'white',
                }}
            >
                <div 
                    style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        zIndex: 1,
                    }}
                />
                <div  style={{ position: 'relative', zIndex: 2 }}>
                    <h3 style={{ color: '#00FFCC' ,fontWeight:"700", fontSize:"25px",lineHeight:"24px"}}>IF-GAMES</h3> 
                    <h1 className='header-image'> {language === "en" ? "Privacy Policy" : "ساسية الخصوصية "}</h1>
                </div>
            </div>
        </>
    );
}

export default Policyheader;
